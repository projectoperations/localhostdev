<?php
require 'vendor/autoload.php';
echo "<h2 style='text-align: center;'>Hello from container: " . gethostname() . "</h2>";
phpinfo();