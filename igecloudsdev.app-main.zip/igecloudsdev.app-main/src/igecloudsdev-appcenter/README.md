# IGE Project Service Codespaces 

[![Board Status](https://dev.azure.com/projectservice/d5a8e30a-2109-4aec-99ed-40e91f8c258e/77b5aeb0-1146-42c5-832f-167d138a3f5c/_apis/work/boardbadge/52607900-cfa3-4d38-84fe-080d4d2e9163?columnOptions=1)](https://dev.azure.com/magiconionM/d5a8e30a-2109-4aec-99ed-40e91f8c258e/_boards/board/t/77b5aeb0-1146-42c5-832f-167d138a3f5c/Microsoft.RequirementCategory/)

This repository is dedicated as a reference point for articles published on my blog series:

- [GitHub Codespaces Pro Tips](https://dev.to/pwd9000/series/19195).  

Feel free to work through the articles published on the series, and use this lab as a reference to learn about GitHub Codespaces.
